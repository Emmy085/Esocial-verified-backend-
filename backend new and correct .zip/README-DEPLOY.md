# E-Social Verified Logs — Backend Deployment Guide

## 🔐 Admin Password
- **Email:** `Emmanuelalakli16@gmail.com`  (or just type `admin` as the email)
- **Password:** `Emmy$1234`
- **How to access:** On the login screen, enter the email + password above.
  Or from the dashboard, tap the sidebar logo 5 times quickly → secret admin portal.

---

## STEP 1 — Set Up Supabase (Free Database)

1. Go to **supabase.com** → Create a new project (free)
2. Give it a name (e.g. "esocial"), pick a **strong database password**, choose a region
3. Once created, go to **SQL Editor → New Query**
4. Copy the entire content of `supabase-schema.sql` and paste → click **Run**
5. This creates all your tables (users, accounts, transactions, etc.)
6. Go to **Settings → API** and copy:
   - `Project URL` → this is your `SUPABASE_URL`
   - `service_role` key (NOT anon key) → this is your `SUPABASE_SERVICE_KEY`

---

## STEP 2 — Deploy Backend on Render.com (Free)

1. Push this `backend` folder to a **GitHub repo** (create a new repo, upload the files)
2. Go to **render.com** → Sign up free → New → Web Service
3. Connect your GitHub repo
4. Settings:
   - **Name:** `esocial-api`
   - **Build Command:** `npm install`
   - **Start Command:** `node server.js`
   - **Instance Type:** Free
5. Click **Add Environment Variable** and add ALL of these:

```
PORT                = 3000
NODE_ENV            = production
JWT_SECRET          = esvl_super_secret_jwt_key_change_this_2026_Emmy
ADMIN_EMAIL         = Emmanuelalakli16@gmail.com
ADMIN_PASSWORD      = Emmy$1234
ADMIN_USERNAME      = Emmy
SUPABASE_URL        = https://YOUR_PROJECT.supabase.co
SUPABASE_SERVICE_KEY = YOUR_SERVICE_ROLE_KEY
FIVESIM_API_KEY     = YOUR_5SIM_KEY
SMM_PANEL_URL       = https://realsimplesocial.com/api
SMM_PANEL_KEY       = YOUR_SMM_KEY
FLW_PUBLIC_KEY      = FLWPUBK-7f91f32b53ef757b2a2974fef058105b-X
FLW_SECRET_KEY      = YOUR_FLW_SECRET_KEY
FRONTEND_URL        = https://your-site.netlify.app
REFERRAL_PERCENT    = 5
NGN_RATE            = 1600
```

6. Click **Deploy** → wait ~2 minutes
7. You'll get a URL like: `https://esocial-api.onrender.com`
   → Copy this URL

---

## STEP 3 — Connect Frontend to Backend

Open the `frontend/index.html` file and find this line near the top:

```javascript
window.ESVL_BACKEND_URL = 'http://localhost:3000/api';
```

Change it to:
```javascript
window.ESVL_BACKEND_URL = 'https://esocial-api.onrender.com/api';
```

Save, re-zip the frontend folder, re-upload to Netlify.

---

## STEP 4 — Deploy Frontend on Netlify

1. Go to **netlify.com** → New site → Deploy manually
2. Drag and drop the `frontend` **folder** (not the zip)
3. Done — your site is live!

---

## LOCAL TESTING (Before Deploying)

1. Install Node.js from nodejs.org
2. In the `backend` folder, create a `.env` file (copy `.env.example`, fill in values)
3. Run: `npm install`
4. Run: `node server.js`
5. Backend runs at `http://localhost:3000`
6. Open `frontend/index.html` in browser — registration and login will work

---

## Profit System Explained

When a user buys a number:
- 5SIM charges e.g. ₦800 (supplier cost)
- You set 20% markup in Admin → Profit Settings
- User is charged ₦960 (₦800 × 1.20)
- **₦160 is your profit — stays in the system**
- ₦800 is sent to 5SIM API

Same for Social Boost (SMM Panel) and Gift Cards.
Verified Accounts: you set the price manually, all revenue is yours.

